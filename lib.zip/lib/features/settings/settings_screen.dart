import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/app_theme.dart';
import '../../core/theme/theme_provider.dart';
import '../../core/l10n/language_provider.dart';

// ═══════════════════════════════════════════════════════════════
// SettingsScreen — Page des paramètres de PharmaAI
//
// Fonctionnalités :
//  • Choix du thème : Clair / Sombre / Système (3 boutons radio)
//  • Choix de la langue : Français / English / العربية (avec drapeaux)
//  • Toggle notifications (état local pour l'instant)
//
// Utilise : themeProvider + languageProvider (Riverpod)
// Design  : respecte Theme.of(context) — compatible clair/sombre
// ═══════════════════════════════════════════════════════════════

// ── Provider local pour les notifications (SharedPreferences plus tard) ──
final notificationsEnabledProvider = StateProvider<bool>((ref) => true);

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // Récupérer l'état actuel du thème et de la langue
    final themeMode   = ref.watch(themeProvider);
    final themeNotif  = ref.read(themeProvider.notifier);
    final currentLang = ref.watch(languageProvider);
    final langNotif   = ref.read(languageProvider.notifier);
    final notifEnabled = ref.watch(notificationsEnabledProvider);

    // Couleurs issues du thème actif
    final colorScheme = Theme.of(context).colorScheme;
    final textTheme   = Theme.of(context).textTheme;

    return Scaffold(
      // ── AppBar ─────────────────────────────────────────────────
      appBar: AppBar(
        title: const Text('Paramètres'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),

      // ── Corps de la page ──────────────────────────────────────
      body: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
        children: [

          // ════════════════════════════════════════════════════
          // SECTION 1 : Apparence (Thème)
          // ════════════════════════════════════════════════════
          _SectionTitle(
            icon : Icons.palette_outlined,
            label: 'Apparence',
            color: colorScheme.primary,
          ),
          const SizedBox(height: 8),

          // Carte contenant les 3 options de thème
          Card(
            child: Column(
              children: [

                // Option : Clair
                _ThemeOption(
                  icon     : Icons.light_mode_rounded,
                  label    : 'Clair',
                  subtitle : 'Fond blanc, texte sombre',
                  value    : ThemeMode.light,
                  groupValue: themeMode,
                  onChanged: (val) => themeNotif.setTheme(val!),
                  iconColor: Colors.orange,
                ),

                const Divider(height: 1, indent: 56),

                // Option : Sombre
                _ThemeOption(
                  icon     : Icons.dark_mode_rounded,
                  label    : 'Sombre',
                  subtitle : 'Fond noir, texte clair',
                  value    : ThemeMode.dark,
                  groupValue: themeMode,
                  onChanged: (val) => themeNotif.setTheme(val!),
                  iconColor: AppTheme.primaryBlueDark,
                ),

                const Divider(height: 1, indent: 56),

                // Option : Système
                _ThemeOption(
                  icon     : Icons.brightness_auto_rounded,
                  label    : 'Automatique',
                  subtitle : 'Suit les réglages du téléphone',
                  value    : ThemeMode.system,
                  groupValue: themeMode,
                  onChanged: (val) => themeNotif.setTheme(val!),
                  iconColor: AppTheme.green,
                ),

              ],
            ),
          ),

          const SizedBox(height: 28),

          // ════════════════════════════════════════════════════
          // SECTION 2 : Langue
          // ════════════════════════════════════════════════════
          _SectionTitle(
            icon : Icons.language_rounded,
            label: 'Langue',
            color: colorScheme.primary,
          ),
          const SizedBox(height: 8),

          // Carte contenant les 3 langues disponibles
          Card(
            child: Column(
              children: [

                // Français
                _LanguageOption(
                  flag    : '🇫🇷',
                  label   : 'Français',
                  locale  : const Locale('fr'),
                  current : currentLang,
                  onTap   : () => langNotif.setLocale(const Locale('fr')),
                ),

                const Divider(height: 1, indent: 56),

                // Anglais
                _LanguageOption(
                  flag    : '🇬🇧',
                  label   : 'English',
                  locale  : const Locale('en'),
                  current : currentLang,
                  onTap   : () => langNotif.setLocale(const Locale('en')),
                ),

                const Divider(height: 1, indent: 56),

                // Arabe
                _LanguageOption(
                  flag    : '🇸🇦',
                  label   : 'العربية',
                  locale  : const Locale('ar'),
                  current : currentLang,
                  onTap   : () => langNotif.setLocale(const Locale('ar')),
                ),

              ],
            ),
          ),

          const SizedBox(height: 28),

          // ════════════════════════════════════════════════════
          // SECTION 3 : Notifications
          // ════════════════════════════════════════════════════
          _SectionTitle(
            icon : Icons.notifications_outlined,
            label: 'Notifications',
            color: colorScheme.primary,
          ),
          const SizedBox(height: 8),

          Card(
            child: Padding(
              padding: const EdgeInsets.symmetric(
                  horizontal: 16, vertical: 4),
              child: Row(
                children: [

                  // Icône
                  Container(
                    width : 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color       : AppTheme.amber.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(
                      Icons.notifications_active_rounded,
                      color: AppTheme.amber,
                      size : 20,
                    ),
                  ),

                  const SizedBox(width: 14),

                  // Texte
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Activer les notifications',
                          style: textTheme.bodyMedium?.copyWith(
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        Text(
                          'Rappels médicaments et alertes stock',
                          style: textTheme.bodySmall?.copyWith(
                            color: colorScheme.onSurface.withOpacity(0.6),
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Switch
                  Switch(
                    value    : notifEnabled,
                    onChanged: (val) => ref
                        .read(notificationsEnabledProvider.notifier)
                        .state = val,
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 28),

          // ════════════════════════════════════════════════════
          // SECTION 4 : À propos (informatif)
          // ════════════════════════════════════════════════════
          _SectionTitle(
            icon : Icons.info_outline_rounded,
            label: 'À propos',
            color: colorScheme.primary,
          ),
          const SizedBox(height: 8),

          Card(
            child: Column(
              children: [

                // Version de l'app
                ListTile(
                  leading: Container(
                    width : 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color       : colorScheme.primary.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(
                      Icons.local_pharmacy_rounded,
                      color: colorScheme.primary,
                      size : 20,
                    ),
                  ),
                  title   : const Text('PharmaAI'),
                  subtitle: const Text('Version 1.0.0'),
                  trailing: Icon(
                    Icons.chevron_right_rounded,
                    color: colorScheme.onSurface.withOpacity(0.4),
                  ),
                ),

                const Divider(height: 1, indent: 56),

                // Politique de confidentialité (placeholder)
                ListTile(
                  leading: Container(
                    width : 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color       : AppTheme.green.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(
                      Icons.privacy_tip_outlined,
                      color: AppTheme.green,
                      size : 20,
                    ),
                  ),
                  title   : const Text('Politique de confidentialité'),
                  trailing: Icon(
                    Icons.chevron_right_rounded,
                    color: colorScheme.onSurface.withOpacity(0.4),
                  ),
                  onTap: () {
                    // TODO : ouvrir politique de confidentialité
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Bientôt disponible'),
                      ),
                    );
                  },
                ),
              ],
            ),
          ),

          // Espace en bas pour le scroll confortable
          const SizedBox(height: 40),
        ],
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════
// Widget : Titre de section (icône + label)
// ════════════════════════════════════════════════════════════════
class _SectionTitle extends StatelessWidget {
  final IconData icon;
  final String   label;
  final Color    color;

  const _SectionTitle({
    required this.icon,
    required this.label,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, size: 18, color: color),
        const SizedBox(width: 8),
        Text(
          label.toUpperCase(),
          style: Theme.of(context).textTheme.labelSmall?.copyWith(
            color      : color,
            fontWeight : FontWeight.bold,
            letterSpacing: 1.2,
          ),
        ),
      ],
    );
  }
}

// ════════════════════════════════════════════════════════════════
// Widget : Option de thème (radio button stylisé)
// ════════════════════════════════════════════════════════════════
class _ThemeOption extends StatelessWidget {
  final IconData  icon;
  final String    label;
  final String    subtitle;
  final ThemeMode value;
  final ThemeMode groupValue;
  final Color     iconColor;
  final void Function(ThemeMode?) onChanged;

  const _ThemeOption({
    required this.icon,
    required this.label,
    required this.subtitle,
    required this.value,
    required this.groupValue,
    required this.iconColor,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final isSelected = value == groupValue;
    final colorScheme = Theme.of(context).colorScheme;

    return RadioListTile<ThemeMode>(
      value      : value,
      groupValue : groupValue,
      onChanged  : onChanged,
      activeColor: colorScheme.primary,
      contentPadding: const EdgeInsets.symmetric(
          horizontal: 16, vertical: 4),
      title: Row(
        children: [
          // Icône dans un cercle coloré
          Container(
            width : 40,
            height: 40,
            decoration: BoxDecoration(
              color       : iconColor.withOpacity(0.12),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: iconColor, size: 20),
          ),
          const SizedBox(width: 14),
          // Textes
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    fontWeight: isSelected
                        ? FontWeight.bold
                        : FontWeight.normal,
                  ),
                ),
                Text(
                  subtitle,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: colorScheme.onSurface.withOpacity(0.6),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════
// Widget : Option de langue (drapeau emoji + nom + coche)
// ════════════════════════════════════════════════════════════════
class _LanguageOption extends StatelessWidget {
  final String flag;
  final String label;
  final Locale locale;
  final Locale current;
  final VoidCallback onTap;

  const _LanguageOption({
    required this.flag,
    required this.label,
    required this.locale,
    required this.current,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    // La langue est-elle actuellement sélectionnée ?
    final isSelected = locale.languageCode == current.languageCode;
    final colorScheme = Theme.of(context).colorScheme;

    return ListTile(
      onTap         : onTap,
      contentPadding: const EdgeInsets.symmetric(
          horizontal: 16, vertical: 4),

      // Drapeau dans un cercle
      leading: Container(
        width : 40,
        height: 40,
        decoration: BoxDecoration(
          // Fond légèrement coloré si sélectionné
          color       : isSelected
              ? colorScheme.primary.withOpacity(0.1)
              : colorScheme.onSurface.withOpacity(0.06),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Center(
          child: Text(flag, style: const TextStyle(fontSize: 20)),
        ),
      ),

      // Nom de la langue
      title: Text(
        label,
        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
          fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
          color     : isSelected ? colorScheme.primary : null,
        ),
      ),

      // Coche si sélectionnée, sinon rien
      trailing: isSelected
          ? Icon(
        Icons.check_circle_rounded,
        color: colorScheme.primary,
      )
          : Icon(
        Icons.radio_button_unchecked_rounded,
        color: colorScheme.onSurface.withOpacity(0.3),
      ),
    );
  }
}