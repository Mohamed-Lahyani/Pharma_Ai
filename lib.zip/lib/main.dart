import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'firebase_options.dart';

// ── Écrans existants ──────────────────────────────────────────
import 'features/auth/login_screen.dart';
import 'features/auth/register_screen.dart';
import 'features/admin/admin_home_screen.dart';
import 'features/client/home/client_home_screen.dart';
import 'package:pharma_ai/features/client/profile/profile_screen.dart';

// ── Nouvel écran Paramètres ───────────────────────────────────
import 'features/settings/settings_screen.dart';

// ── Thème (nouveaux fichiers) ─────────────────────────────────
import 'core/theme/app_theme.dart';
import 'core/theme/theme_provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  // ProviderScope est obligatoire pour que Riverpod fonctionne
  runApp(
    const ProviderScope(
      child: MyApp(),
    ),
  );
}

// ConsumerWidget au lieu de StatelessWidget → accès aux providers
class MyApp extends ConsumerWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // Écouter le thème choisi par l'utilisateur
    final themeMode = ref.watch(themeProvider);

    return MaterialApp(
      title                     : 'PharmaAI',
      debugShowCheckedModeBanner: false,

      // ── Thèmes ───────────────────────────────────────────────
      theme     : AppTheme.lightTheme, // clair
      darkTheme : AppTheme.darkTheme,  // sombre
      themeMode : themeMode,           // suit le choix utilisateur

      // ── Routes ───────────────────────────────────────────────
      initialRoute: '/',
      routes: {
        '/'         : (context) => const LoginScreen(),
        '/admin'    : (context) => const AdminHomeScreen(),
        '/client'   : (context) => const ClientHomeScreen(),
        '/register' : (context) => const RegisterScreen(),
        '/profile'  : (context) => const ProfileScreen(),
        '/settings' : (context) => const SettingsScreen(), // ← NOUVEAU
      },
    );
  }
}